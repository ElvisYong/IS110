from q2c import search_with_keyword

# Test Case:

print("Expected: ['Berkeley', 'UCLA']")
print("Actual  : " + str(search_with_keyword('universities-1.txt', 'california')))