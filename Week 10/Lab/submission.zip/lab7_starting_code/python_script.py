def my_test_func(param1, param2):
    """
    This is a test function that takes in two parameters and returns a number.
    The two parameters are compared. 0 or 1 is returned.
    """
    if (param1 < param2):
        return 0
    else:
        return 1
def another_function():
    """This is a function without any parameter."""
    pass
def third_funct():
    """This is a function
    that has two lines of docstring."""
    print("hello")
