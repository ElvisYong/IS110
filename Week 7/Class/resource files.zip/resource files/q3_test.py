import q3


# Triangle
#=========

# Test case 1
q3.print_triangle('*',3)
print()
# Test case 2
q3.print_triangle('*',5)
print()


# Frame
#=======

# Test case 1
q3.print_frame('*',3,4)
print()
# Test case 2
q3.print_frame('#',5,6)
print()
# Test case 2
q3.print_frame('$',2,2)


