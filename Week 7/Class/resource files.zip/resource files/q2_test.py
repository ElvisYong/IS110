import q2

sentence = input('\nEnter a string:')
result = q2.transform_string(sentence)
print('\nThe transformed text is:',result)
