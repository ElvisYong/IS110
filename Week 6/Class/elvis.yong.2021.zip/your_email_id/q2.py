# =====
# q2.py
# =====
# Name: Yong Yu En, Elvis 
# Email ID: elvis.yong.2021

def display_strings(str_list, ch):
    # Modify the code below
    if str_list:
        no_of_items = len(str_list)
        max_length_of_word = max(len(i) for i in str_list)
        max_padding = max_length_of_word + no_of_items

        for count, i in enumerate(str_list):
            if count == len(str_list) - 1:
                spaces = ''
            spaces = ' ' * no_of_items
            print(spaces + i + ch * (max_padding - no_of_items - len(i)))
            no_of_items -= 1
    

