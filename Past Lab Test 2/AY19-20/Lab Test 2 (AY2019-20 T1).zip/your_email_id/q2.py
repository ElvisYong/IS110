# Name:
# Email ID:

def get_longer_words(file_name):
    # Modify the code below.
    return None