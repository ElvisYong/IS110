# Name:
# Email ID:

def compute_product(num_list):
    # Modify the code below.
    return None
    