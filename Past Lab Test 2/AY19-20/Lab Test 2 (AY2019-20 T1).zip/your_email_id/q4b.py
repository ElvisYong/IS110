# Name:
# Email ID:

def get_relation_through_link(family_dict, link):
    # Modify the code below.
    return None
    