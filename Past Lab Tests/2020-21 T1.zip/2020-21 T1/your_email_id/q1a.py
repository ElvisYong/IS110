# Name:
# Email ID:

def get_tank_volume(width, depth, height):
    # Replace the code below with your implementation.
    return (width * depth * height) // 1000
