# Name:
# Email ID:

def trace_contacts_2(patient, history, m, n):
    # Replace the code below with your implementation.
    return None